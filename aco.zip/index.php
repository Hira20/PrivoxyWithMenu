<?php
include 'config.php';
if (!isset($_GET['referrer']) || $_GET['referrer'] != "Auth") {
    $i = rand(0,sizeof($red_link)-1);
    header("location: $red_link[$i]");
    exit();
}
?>