<?php

include 'register.php';
include 'approve.php';
include 'ban.php';

?>