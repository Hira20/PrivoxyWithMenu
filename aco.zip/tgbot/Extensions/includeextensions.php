<?php

include 'keyboard.php';
include 'texts.php';
include 'cmds.php';
include 'newmember.php';

?>